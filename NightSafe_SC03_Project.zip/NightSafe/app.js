const $=id=>document.getElementById(id);
let journey=null, liveTimer=null, connected=true, locationProgress=48, escalationTimer=null;

function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}
function fmt(d){return new Date(d).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}
function setDefaultEta(){const d=new Date(Date.now()+30*60000);d.setSeconds(0,0);$("eta").value=d.toISOString().slice(0,16)}
setDefaultEta();

document.querySelectorAll(".tab").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
  $("travellerView").classList.toggle("hidden",btn.dataset.view!=="traveller");
  $("contactView").classList.toggle("hidden",btn.dataset.view!=="contact");
});

$("shareBtn").onclick=()=>{
  journey={
    start:$("start").value||"Start",
    destination:$("destination").value||"Destination",
    eta:$("eta").value,
    contact:$("contactName").value||"Trusted Contact",
    arrived:false,
    lastKnown:"Kochi",
    lastUpdate:new Date(),
    sharedAt:new Date()
  };
  $("activeCard").classList.remove("hidden");
  $("shareResult").classList.remove("hidden");
  $("shareResult").textContent=`Journey link created for ${journey.contact}. Trusted contact can now follow your journey.`;
  $("journeyTitle").textContent=`${journey.start} → ${journey.destination}`;
  $("startLabel").textContent=journey.start;
  $("endLabel").textContent=journey.destination;
  $("etaText").textContent=fmt(journey.eta);
  updateContact();
  toast("Journey shared safely");
};

function updateContact(){
  if(!journey)return;
  $("noJourney").classList.add("hidden");$("followContent").classList.remove("hidden");
  $("followName").textContent=journey.contact;
  $("contactAvatar").textContent=journey.contact[0].toUpperCase();
  $("followRoute").textContent=`${journey.start} → ${journey.destination}`;
  $("followEta").textContent=fmt(journey.eta);
  $("followLast").textContent=journey.lastKnown+" • "+fmt(journey.lastUpdate);
  $("followJourneyStatus").textContent=journey.arrived?"Arrived safely":(connected?"Live":"Signal lost");
}

function updatePosition(){
  if(!journey || !connected)return;
  locationProgress=Math.min(86,locationProgress+2);
  journey.lastKnown=`Route point ${locationProgress}%`;
  journey.lastUpdate=new Date();
  $("locationText").textContent=journey.lastKnown;
  $("updatedText").textContent=fmt(journey.lastUpdate);
  $("currentPin").style.left=locationProgress+"%";
  $("followPin").style.left=locationProgress+"%";
  updateContact();
}

$("locationBtn").onclick=()=>{
  if(!journey){toast("Share a journey first");return}
  if(liveTimer){clearInterval(liveTimer);liveTimer=null;$("locationBtn").textContent="📍 Start Live Location";toast("Live location paused");return}
  connected=true;setConnection(true);$("locationBtn").textContent="⏸ Pause Live Location";
  updatePosition();liveTimer=setInterval(updatePosition,4000);toast("Live location started");
};

function setConnection(ok){
  connected=ok;
  $("connectionBadge").textContent=ok?"● Online":"● Signal Lost";
  $("connectionBadge").className="badge "+(ok?"online":"");
  $("journeyStatus").textContent=ok?"Live":"Signal Lost";
  $("journeyStatus").className="badge "+(ok?"online":"");
  updateContact();
}

$("signalBtn").onclick=()=>{
  if(!journey){toast("Share a journey first");return}
  connected=!connected;setConnection(connected);
  if(!connected){
    $("alertBox").classList.remove("hidden");
    $("alertBox").textContent=`⚠ Signal lost. Last known location is retained: ${journey.lastKnown} at ${fmt(journey.lastUpdate)}.`;
    $("signalBtn").textContent="Restore Signal";
    toast("Demo: mobile signal lost");
  }else{
    $("alertBox").classList.add("hidden");$("signalBtn").textContent="Simulate Signal Loss";
    updatePosition();toast("Signal restored — location synced");
  }
};

$("arriveBtn").onclick=()=>{
  if(!journey){toast("Share a journey first");return}
  journey.arrived=true;
  if(liveTimer){clearInterval(liveTimer);liveTimer=null}
  $("journeyStatus").textContent="Arrived";$("journeyStatus").className="badge online";
  $("alertBox").classList.remove("hidden");$("alertBox").style.background="#eefaf2";$("alertBox").style.color="#176d39";$("alertBox").textContent="✓ Arrival confirmed. Trusted contact has been notified.";
  updateContact();toast("Arrival check-in sent");
  if(escalationTimer)clearTimeout(escalationTimer);
};

$("callBtn").onclick=()=>toast("Demo: opening phone call to traveller");
$("lastLocationBtn").onclick=()=>{
  if(!journey){toast("No active journey");return}
  document.querySelector('[data-view="traveller"]').click();
  $("activeCard").scrollIntoView({behavior:"smooth"});
  toast(`Last known location: ${journey.lastKnown}`);
};

function monitorMissedCheckin(){
  if(escalationTimer)clearTimeout(escalationTimer);
  if(!journey || journey.arrived)return;
  const delay=Math.max(1000,new Date(journey.eta).getTime()-Date.now());
  escalationTimer=setTimeout(()=>{
    if(journey && !journey.arrived){
      $("alertBox").classList.remove("hidden");
      $("alertBox").textContent="🚨 MISSED CHECK-IN: Expected arrival time has passed. Trusted contact should check the last known location and contact the traveller.";
      $("contactAlert").classList.remove("hidden");
      $("contactAlert").textContent="🚨 Missed check-in escalation active. Review the last known location and contact the traveller.";
      $("followStatus").textContent="Escalation";
      $("followStatus").className="badge";
      updateContact();
    }
  },delay);
}

const oldShare=$("shareBtn").onclick;
$("shareBtn").addEventListener("click",()=>setTimeout(monitorMissedCheckin,50));
