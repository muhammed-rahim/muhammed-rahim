# NightSafe SC-03

A front-end prototype for a late-night journey safety companion.

## Features
- Share Journey
- Trusted Contact Follow page
- Add-on Live Location simulation
- Signal-loss simulation with last-known location
- Automatic location updates while connected
- Arrival Check-in
- Missed Check-in escalation
- Mobile responsive red/white safety UI

## Run
No installation is required.

1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Click **Share Journey**.
4. Open **Trusted Contact** to follow the simulated journey.
5. Click **Start Live Location**.
6. Use **Simulate Signal Loss** to demonstrate offline behavior.
7. Click **I've Arrived Safely** to demonstrate check-in.

## Note
This is a browser prototype. The live location is simulated so it can be demonstrated without a backend, GPS service, authentication, SMS provider, or map API.

For a production version, connect a secure backend/database, real browser/device geolocation, authenticated share tokens, push/SMS notifications, and a real map provider.
